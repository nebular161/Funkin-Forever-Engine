Drop you custom music here!
It should be in .ogg otherwise it won't work!!!

BEWARE!!!
This is not about your Song's music (Instrumental or Voices),
if you want to implement Song Inst/Voices, go to "mods/songs/" folder

This is simply for being used with Lua's "playMusic".